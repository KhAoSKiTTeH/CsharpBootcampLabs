﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampEight
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, sum = 0;

            Console.WriteLine("Enter a number: ");
            num = Convert.ToInt32(Console.ReadLine());

            while (num != 0)
            {
                switch (num%2)
                {
                    case 0:
                        Console.WriteLine("Adding " + num);
                        sum += num;
                        break;
                    default:
                        Console.WriteLine("Not adding " + num);
                        break;
                 }

                num--;
            }

            Console.WriteLine("Your total is: " + sum);
            Console.ReadLine();

        }
    }
}
