﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RomanToArabicLib;

namespace RomanToArabicUnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ConvertIto1()
        {
            var roman = new RomanToArabicConvertor();
            var result = roman.convert("I");

            Assert.AreEqual(result, 1);
        }

        [TestMethod]
        public void ConverIVto4()
        {
            var roman = new RomanToArabicConvertor();
            var result = roman.convert("IV");

            Assert.AreEqual(result, 4);
        }

        [TestMethod]
        public void ConverIXto9()
        {
            var roman = new RomanToArabicConvertor();
            var result = roman.convert("IX");

            Assert.AreEqual(result, 9);
        }
        [TestMethod]
        public void ConvertVIIto7()
        {
            var roman = new RomanToArabicConvertor();
            var result = roman.convert("VII");

            Assert.AreEqual(result, 7);
        }

        [TestMethod]
        public void ConvertXto10()
        {
            var roman = new RomanToArabicConvertor();
            var result = roman.convert("X");

            Assert.AreEqual(result, 10);
        }
    }
}
