﻿using LeapYear;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace LeapYearXUnitTests
{
    public class XUniteTests
    {
        LeapYearCalc x = new LeapYearCalc();

        [Theory]
        [InlineData(1996)] //true 
        [InlineData(2000)] //true
        [InlineData(2052)] //true
        [InlineData(1904)] //true
        [InlineData(2072)] //true
        [InlineData(2012)] //true
        public void TestLeapYear(int value)
        {
            Assert.True(x.isLeapYear(value));
        }

        [Theory]
        [InlineData(1994)] //false
        [InlineData(2001)] //false
        [InlineData(1900)] //false
        [InlineData(2005)] //false
        [InlineData(2039)] //false
        [InlineData(1946)] //false
        public void TestNotLeapYear(int value)
        {
            Assert.False(x.isLeapYear(value));
        }

    }
}
