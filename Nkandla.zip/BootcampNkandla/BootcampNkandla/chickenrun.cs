﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampNkandla
{
    public class chickenrun
    {
        private int numberOfChickens;

        public chickenrun()
        {

        }

        public int NumerOfChickens
        {
            get { return this.numberOfChickens; }
            set { this.numberOfChickens = value; }
        }
    }
}
