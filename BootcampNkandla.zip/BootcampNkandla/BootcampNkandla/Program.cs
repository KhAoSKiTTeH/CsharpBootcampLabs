﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//was on the completely wrong track, looked at the instructions in NKandla_CSharp_Master 
//which is much better than on the community page, 
//and they made everything a bit more clear on what to do but I ran out of time. 
//Studying the NKandla_Master to make sure I undestand


namespace BootcampNkandla
{
    class Program
    {
        interface Ivisitor
        {
             void visit(homestead h);
        }
        public class homestead
        {
            protected string name;
            protected string districs;
            protected string province;
            protected string country;

            public void accept(politician visitor)
            {
                visit(this);
            }
        }

        public class person
        {
            protected string name;
            protected int age;
            protected string gender;
            protected string type;
        }

        public class nkandla : homestead
        {
            protected bool swimming_pool;
            protected bool chicken_run;
            protected bool ampitheatre;

            public void accept(politician visitor)
            {
                if (visitor.party == "ANC")
                    visit(this);
            }
        }

        public class politician : person
        {
            protected string party;
        }

        public class jacob_zuma : politician
        {
            protected bool architect;
            protected bool lawyer;
        }

        public class helen_zille : politician, Ivisitor 
        {
            public void accept()
            {

            }
        }

        static void Main(string[] args)
        {
            
        }
    }
}
