﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampNkandla
{
    class Program
    {
        static void Main(string[] args)
        {
            homestead home = new homestead("Zuma", "Wierda", "Gauteng", "ZA");
            Nkandla nkandla = new Nkandla("Zuma", "Wierda", "Gauteng", "ZA");

            //Testing
            string temp = "Homestead:" + " Name [Zuma] District [Wierda] Province [Gauteng] Country [ZA]";
            if (temp.Equals(home.ToString()))
                Console.WriteLine("Homestead initiated correct");

            chickenrun chickens = new chickenrun();
            chickens.NumerOfChickens = 10;

            swimmingpool firePool = new swimmingpool();
            firePool.Height = 75;
            firePool.Width = 75;

            ampitheatre ampitheatre = new ampitheatre();
            ampitheatre.NumberOfSeats = 1000;

            nkandla.ChickenRun = chickens;
            nkandla.SwimmingPool = firePool;
            nkandla.Ampitheatre = ampitheatre;
            
            Console.WriteLine("Nkandla chickenrun: NumberOfChickens = " + chickens.NumerOfChickens);
            Console.WriteLine("Nkandla swimmingpool: Width = " + firePool.Width + " Height: " + firePool.Height);
            Console.WriteLine("Nkandla ampitheatre: NumberOfSeats = " + ampitheatre.NumberOfSeats);

            politician JacobZuma = new politician("Jacob Zuma", 43, Gender.MALE, PersonType.President, PartyType.ANC);
            politician HelenZille = new politician("Hellen Zille", 50, Gender.FEMALE, PersonType.Politician, PartyType.DA);
            politician JuliusMalema = new politician("Julius Malema", 38, Gender.MALE, PersonType.Politician, PartyType.EFF);

            Lawyer BarryRoux = new Lawyer("Barry Roux", 55, Gender.MALE, PersonType.Lawyer, PartyType.ANC);
            architect GregWright = new architect("Greg Wright", 62, Gender.MALE, PersonType.Architect, PartyType.ANC);

            //Output
            Console.WriteLine(JacobZuma.ToString());
            Console.WriteLine(HelenZille.ToString());
            Console.WriteLine(JuliusMalema.ToString());
            Console.WriteLine(BarryRoux.ToString());
            Console.WriteLine(GregWright.ToString());

            home.accept(HelenZille);
            home.accept(JuliusMalema);
            home.accept(JacobZuma);

            Console.ReadLine();

        }
    }
}
