﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampNkandla
{
    public class ampitheatre
    {
        private int numberOfSeats;

        public ampitheatre()
        {
        }

        public int NumberOfSeats
        {
            get { return this.numberOfSeats; }
            set { this.numberOfSeats = value; }
        }
    }
}
