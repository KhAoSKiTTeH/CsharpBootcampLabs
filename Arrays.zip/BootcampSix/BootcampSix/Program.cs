﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampSix
{
    class Program
    {
        static void Main(string[] args)
        {
            int arrSize = 5;
            int[] numbers = new int[arrSize];
            
            Console.WriteLine("Please enter 5 numbers: \n");

            for (int i = 0; i < arrSize; i++)
                 numbers[i] = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Youre numbers in reverse are: ");

            for (int i = (arrSize-1); i >= 0; i--)
                Console.WriteLine(numbers[i]);

            Console.ReadLine();
            
        }
    }
}
