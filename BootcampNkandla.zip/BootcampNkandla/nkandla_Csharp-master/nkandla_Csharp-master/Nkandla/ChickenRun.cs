﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nkandla
{
    class ChickenRun
    {
        private int numberOfChickens;

        public ChickenRun()
        {

        }

        public int NumerOfChickens
        {
            get { return this.numberOfChickens; }
            set { this.numberOfChickens = value; }
        }
    }
}
