﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampNkandla
{
    public class Nkandla : homestead
    {

        private chickenrun chickenRun;
        private swimmingpool swimmingPool;
        private ampitheatre ampitheatre;

        public Nkandla(string name, string district, string province, string country) : base(name, district, province, country)
        {
        }

        public chickenrun ChickenRun
        {
            get { return this.chickenRun; }
            set { this.chickenRun = value; }
        }

        public swimmingpool SwimmingPool
        {
            get { return this.swimmingPool; }
            set { this.swimmingPool = value; }
        }

        public ampitheatre Ampitheatre
        {
            get { return this.ampitheatre; }
            set { this.ampitheatre = value; }
        }
    }
}
