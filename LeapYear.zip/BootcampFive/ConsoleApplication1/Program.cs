﻿using LeapYear;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            LeapYearCalc x = new LeapYearCalc();

            Console.WriteLine("Is 1994 a leap year? " + (x.isLeapYear(1994)).ToString());
            Console.WriteLine("Is 2001 a leap year? " + (x.isLeapYear(2001)).ToString());
            Console.WriteLine("Is 1900 a leap year? " + (x.isLeapYear(1900)).ToString());
            Console.WriteLine("Is 1996 a leap year? " + (x.isLeapYear(1996)).ToString());
            Console.WriteLine("Is 2000 a leap year? " + (x.isLeapYear(2000)).ToString());
            Console.WriteLine("Is 2052 a leap year? " + (x.isLeapYear(2052)).ToString());
            Console.WriteLine("Is 1904 a leap year? " + (x.isLeapYear(1904)).ToString());
            Console.WriteLine("Is 2072 a leap year? " + (x.isLeapYear(2072)).ToString());
            Console.WriteLine("Is 2012 a leap year? " + (x.isLeapYear(2012)).ToString());

            Console.ReadLine();

    }
}
}
