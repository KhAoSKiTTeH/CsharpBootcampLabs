﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeapYear
{
    public class LeapYearCalc
    {
        private bool leap;
        public bool isLeapYear(int year)
        {
            if (year % 4 == 0)
            {
                if (year % 100 == 0 && year % 400 == 0)
                    leap = true;
                else if (year % 100 == 0 && year % 400 != 0)
                    leap = false;
                else
                    leap = true;
            }
            else
                leap = false;

            return leap;
        }
    }
}
