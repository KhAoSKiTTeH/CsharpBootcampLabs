﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//was on the completely wrong track, looked at the instructions in NKandla_CSharp_Master 
//which is much better than on the community page, 

namespace BootcampNkandla
{
    public class homestead
    {
        private string name;
        private string district;
        private string province;
        private string country;

        public homestead(string name, string district, string province, string country)
        {
            this.name = name;
            this.district = district;
            this.province = province;
            this.country = country;
        }

        public string homeName
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public string homeDistrict
        {
            get { return this.district; }
            set { this.district = value; }
        }

        public string homeProvince
        {
            get { return this.province; }
            set { this.province = value; }
        }

        public string homeCountry
        {
            get { return this.country; }
            set { this.country = value; }
        }

        public void accept(Ivisitor visitor)
        {
            if (visitor != null)
                visitor.visit(this);
        }

        public string ToString()
        {
            return "Homestead:" +
                " Name [" + this.name +
                "] District [" + this.district +
                "] Province [" + this.province +
                "] Country [" + this.country +
                "]";
        }
    }
}
