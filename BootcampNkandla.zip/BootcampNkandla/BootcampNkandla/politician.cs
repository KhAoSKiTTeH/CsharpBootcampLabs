﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampNkandla
{
    public class politician : Person, Ivisitor
    {
        public politician(string name, int age, Gender gender, PersonType type, PartyType politicalParty) : base(name, age, gender, type, politicalParty)
        {

        }

        public void visit(homestead homeStead)
        {
            if (base.Type.Equals(PersonType.Politician) && !base.PoliticalParty.Equals(PartyType.ANC))
                Console.WriteLine(base.Name + ": Pay back the money!");
            else
                Console.WriteLine(base.Name + ", Welcome to Nkandla!");
        }

        public string ToString()
        {
            return "Politician" + base.ToString();
        }
    }
}
