﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootcampSeven
{
    class Program
    {

        static string changeR(int x, string z)
        {
            int[] bills = { 100, 50, 20, 5, 2, 1 };

            for (int i = 0; i < 6; i++)
            {
                if (x - bills[i] >= 0)
                {
                    z += bills[i] + " " ;
                    x -= bills[i];

                    return z = changeR(x, z);
                }
            }

            if (x > 0)
                return z = changeR(x, z);
            else
                return z;
        }
        static void Main(string[] args)
        {
            int price, paid, change;
            string changeBills = "";

            Console.WriteLine("Please enter item price: ");
            price = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter money paid: ");
            paid = Convert.ToInt32(Console.ReadLine());

            change = paid - price;
            changeBills += change + ":";

            changeBills = changeR(change, changeBills);

            Console.WriteLine(changeBills);
            Console.ReadLine();

        }
    }
}
