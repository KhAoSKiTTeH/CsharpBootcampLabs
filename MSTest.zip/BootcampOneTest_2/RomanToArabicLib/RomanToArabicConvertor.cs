﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanToArabicLib
{
    public class RomanToArabicConvertor
    {
        #region [my attempt]
        //    public int convert(string roman)
        //    {
        //        int arabic = 0;            

        //        for (int i = 0; i < roman.Length; i++)
        //        {

        //            string romanSub = roman;

        //            if (i != roman.Length - 1 && roman.Length != 2)
        //                romanSub = (roman[i] + roman[i + 1]).ToString();

        //            if (romanSub != "IV" || romanSub != "IX" || romanSub != "XL" ||
        //                romanSub != "XC" || romanSub != "CD" || romanSub != "CM")
        //            {
        //                switch (roman[i])
        //                {
        //                    case 'I':
        //                        arabic += 1;
        //                        break;
        //                    case 'V':
        //                        arabic += 5;
        //                        break;
        //                    case 'X':
        //                        arabic += 10;
        //                        break;
        //                    case 'L':
        //                        arabic += 50;
        //                        break;
        //                    case 'C':
        //                        arabic += 100;
        //                        break;
        //                    case 'D':
        //                        arabic += 500;
        //                        break;
        //                    case 'M':
        //                        arabic += 1000;
        //                        break;
        //                }
        //            }
        //            else
        //            { 
        //                switch (romanSub)
        //                {
        //                    case "IV":
        //                        arabic += 4;
        //                        break;
        //                    case "IX":
        //                        arabic += 9;
        //                        break;
        //                    case "XL":
        //                        arabic += 40;
        //                        break;
        //                    case "XC":
        //                        arabic += 90;
        //                        break;
        //                    case "CD":
        //                        arabic += 400;
        //                        break;
        //                    case "CM":
        //                        arabic += 900;
        //                        break;
        //                }
        //            }
        //        }

        //        return arabic;
        //    }
        //}
        #endregion

            public static string getRomanLogic(int number, char one, char five, char ten)
            {
                switch (number)
                {
                    case 1:
                    case 2:
                    case 3:
                        return new string(one, number);
                    case 4:
                        return "" + one + five;
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                        return five + new string(one, number - 5);
                    case 9:
                        return ("" + one + ten);
                }
                return "";
            }

            public static string convertThousandsToRoman(int number)
            {
                int thousands = (int)number / 1000;
                return getRomanLogic(thousands, 'M', char.MinValue, char.MinValue);
            }

            public static string convertHundredsToRoman(int number)
            {
                int hundreds = (int)(number % 1000) / 100;
                return getRomanLogic(hundreds, 'C', 'D', 'M');
            }

            public static string convertDizaineToRoman(int number)
            {
                int dizaine = (int)(number % 100) / 10;
                return getRomanLogic(dizaine, 'X', 'L', 'C');
            }

            public static string convertUnitsToRoman(int number)
            {
                int units = (int)(number % 10);
                return getRomanLogic(units, 'I', 'V', 'X');
            }

            public static string convertToRoman(int number)
            {
                return convertThousandsToRoman(number) + convertHundredsToRoman(number) + convertDizaineToRoman(number) + convertUnitsToRoman(number);
            }

            public  int convert(string romanNumber)
            {
                Dictionary<char, int> romanOrder = new Dictionary<char, int>();
                romanOrder.Add('M', 1000);
                romanOrder.Add('D', 500);
                romanOrder.Add('C', 100);
                romanOrder.Add('L', 50);
                romanOrder.Add('X', 10);
                romanOrder.Add('V', 5);
                romanOrder.Add('I', 1);

                int total = 0;
                int currentIndex = 0;
                int stringLength = romanNumber.Length;
                char first = char.MinValue;
                char second = char.MinValue;
                while (currentIndex < stringLength)
                {
                    first = romanNumber[currentIndex];
                    second = char.MinValue;
                    if (currentIndex + 1 < stringLength)
                    {
                        second = romanNumber[currentIndex + 1];
                    }

                    if (second == char.MinValue || romanOrder[first] >= romanOrder[second])
                    {
                        total += romanOrder[first];
                        currentIndex++;
                    }
                    else
                    {
                        total += (romanOrder[second] - romanOrder[first]);
                        currentIndex += 2;
                    }
                }
                return total;
            }
        }
    }

