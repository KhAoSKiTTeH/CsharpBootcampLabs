﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using BootcampNkandla;

namespace XUnitTestsNkandla
{
    public class TestsXUnit
    {
        homestead h = new homestead("Antoinette", "Allens Nek", "Gauteng", "ZA");
        Nkandla n = new Nkandla("Zuma", "Wierda", "Gauteng", "ZA");
        string temph = "Homestead: Name [Antoinette] District [Allens Nek] Province [Gauteng] Country [ZA]";
        string tempn = "Homestead: Name [Zuma] District [Wierda] Province [Gauteng] Country [ZA]";

        [Fact]
        public void TestHomestead()
        {
            Assert.Equal(temph, h.ToString());
        }

        [Fact]
        public void TestNkandla()
        {
            Assert.Equal(tempn, n.ToString());
        }


    }
}
