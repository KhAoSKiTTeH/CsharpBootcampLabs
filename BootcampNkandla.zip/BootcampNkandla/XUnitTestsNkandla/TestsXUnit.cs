﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using BootcampNkandla;

namespace XUnitTestsNkandla
{
    public class TestsXUnit
    {
        homestead h = new homestead("Zuma", "Wierda", "Gauteng", "ZA");
        string temp = "Homestead: Name [Zuma] District [Wierda] Province [Gauteng] Country [ZA]";

        [Fact]
        public void TestHomestead()
        {
            Assert.Equal(temp, h.ToString());
        }

    }
}
