﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//My conversions are broken
namespace BootcampFive
{
    class Program
    {
        static void Main(string[] args)
        {
            int meters, kiloM, miles, hours, minutes, seconds;
            double totalSeconds = 0, totalHours = 0;

            Console.WriteLine("Please enter distance in meters: ");
            meters = Convert.ToInt32(Console.ReadLine());

            kiloM = meters / 1000;
            miles = meters / 1609;

            Console.WriteLine("Please enter time taken (hours, minutes, seconds respectively, press enter after each): \n");
            hours = Convert.ToInt32(Console.ReadLine());
            minutes = Convert.ToInt32(Console.ReadLine());
            seconds = Convert.ToInt32(Console.ReadLine());

            totalSeconds += (hours * 60 * 60) + (minutes * 60) + seconds;
            totalHours += (minutes / 60) + (seconds / 60 / 60) + hours;

            Console.WriteLine("Meters per second: " + Convert.ToDouble(meters / totalSeconds) + "\n");
            Console.WriteLine("Kilometers per hour: " + Convert.ToDouble(kiloM / totalHours) + "\n");
            Console.WriteLine("Miles per hour: " + Convert.ToDouble(miles / totalHours) + "\n");

            Console.ReadLine();
        }
    }
}
